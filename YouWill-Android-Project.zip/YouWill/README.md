# YouWill — Android focus lock

A native Android / Jetpack Compose starter project for a timed focus session.

## What is included

- A dark, polished focus-first interface.
- Custom session length: **5–180 minutes** (inclusive).
- Quick picks and a slider.
- A live countdown that is saved across app restarts.
- No pause or early-unlock control inside the app.
- An emergency dialer action.
- Android screen-pinning fallback on a normal, unmanaged phone.
- Optional Android Device Owner / Lock Task integration for stronger kiosk-style locking.

## Important limitations

YouWill cannot honestly promise an unbreakable lock on a normal personal Android installation. Without Device Owner provisioning, Android only offers user-confirmed screen pinning, which can be exited through system controls. Even managed-device Lock Task mode is not a substitute for emergency access or a guarantee against every possible system-level recovery method.

The emergency dialer and Android keyguard/global actions are intentionally retained. Do not remove emergency access to make the lock stricter.

## Build

Open this folder as a project in Android Studio with Android SDK 35 and JDK 17 installed, then build the `app` debug APK. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and Jetpack Compose.

This source package is **not an APK**. It has not been compiled or tested on a Samsung Galaxy A03 Core in this environment because the Android SDK / Gradle build toolchain is not installed here.

## Strong Lock Task setup (advanced)

The app can use `DevicePolicyManager` Lock Task mode only after it has been provisioned as the device owner. Android's test-device workflow uses ADB and a clean/unprovisioned device. Depending on the phone's setup state, provisioning may require removing accounts or a factory reset. **Back up the phone first** and do not run Device Owner provisioning on your main phone unless you understand that device-management mode can restrict normal phone use.

After installing the app on an eligible test device, the Android device-owner test command is:

```bash
adb shell dpm set-device-owner "com.youwill.app/.YouWillAdminReceiver"
```

The command may fail if the phone is already provisioned or has accounts / other device admins. This is not a step to attempt casually on your everyday phone.

## Package

`com.youwill.app`
