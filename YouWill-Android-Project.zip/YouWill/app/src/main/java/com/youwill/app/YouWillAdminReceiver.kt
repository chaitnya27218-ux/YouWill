package com.youwill.app

import android.app.admin.DeviceAdminReceiver

/** Receives Android device-admin lifecycle callbacks for optional Device Owner mode. */
class YouWillAdminReceiver : DeviceAdminReceiver()
