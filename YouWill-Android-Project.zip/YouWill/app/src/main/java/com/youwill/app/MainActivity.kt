package com.youwill.app

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val Night = Color(0xFF090D18)
private val Panel = Color(0xFF121A2A)
private val Panel2 = Color(0xFF18243A)
private val White = Color(0xFFF5F7FF)
private val Muted = Color(0xFF9AA8C0)
private val Accent = Color(0xFF78E7C0)
private val Blue = Color(0xFF7C9BFF)
private const val PREFS = "youwill_session"
private const val END_AT = "end_at"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(9, 13, 24)
        window.navigationBarColor = AndroidColor.rgb(9, 13, 24)
        window.decorView.systemUiVisibility = 0
        setContent {
            MaterialTheme {
                YouWillRoot()
            }
        }
    }
}

@Composable
private fun YouWillRoot() {
    val context = LocalContext.current
    val activity = context as? Activity
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    var endAt by remember { mutableLongStateOf(prefs.getLong(END_AT, 0L)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var minutes by remember { mutableIntStateOf(25) }
    var minuteText by remember { mutableStateOf("25") }
    var finished by remember { mutableStateOf(false) }

    LaunchedEffect(endAt) {
        if (endAt > 0L) {
            while (true) {
                now = System.currentTimeMillis()
                if (now >= endAt) {
                    endAt = 0L
                    prefs.edit().remove(END_AT).apply()
                    finished = true
                    activity?.let { endFocusLock(it) }
                    break
                }
                delay(1_000)
            }
        }
    }

    val isActive = endAt > 0L && endAt > now
    val remaining = if (isActive) (endAt - now).coerceAtLeast(0L) else 0L
    val deviceOwner = remember {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        dpm.isDeviceOwnerApp(context.packageName)
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Night) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF101B31), Night, Color(0xFF090D18))
                    )
                )
        ) {
            AnimatedContent(targetState = when {
                isActive -> "active"
                finished -> "done"
                else -> "home"
            }, label = "screen") { screen ->
                when (screen) {
                    "active" -> ActiveScreen(
                        remainingMillis = remaining,
                        totalMillis = (endAt - prefs.getLong("session_start", endAt)).coerceAtLeast(1L),
                        onEmergency = { openEmergencyDialer(context) }
                    )
                    "done" -> DoneScreen(onContinue = { finished = false })
                    else -> HomeScreen(
                        minuteText = minuteText,
                        minutes = minutes,
                        strongMode = deviceOwner,
                        onTextChange = { value ->
                            val filtered = value.filter(Char::isDigit).take(3)
                            minuteText = filtered
                            filtered.toIntOrNull()?.takeIf { it in 5..180 }?.let { minutes = it }
                        },
                        onMinutesChange = { value ->
                            minutes = value
                            minuteText = value.toString()
                        },
                        onStart = {
                            val chosen = minuteText.toIntOrNull()?.takeIf { it in 5..180 } ?: return@HomeScreen
                            val start = System.currentTimeMillis()
                            endAt = start + chosen * 60_000L
                            prefs.edit()
                                .putLong(END_AT, endAt)
                                .putLong("session_start", start)
                                .apply()
                            finished = false
                            activity?.let { beginFocusLock(context, it) }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    minuteText: String,
    minutes: Int,
    strongMode: Boolean,
    onTextChange: (String) -> Unit,
    onMinutesChange: (Int) -> Unit,
    onStart: () -> Unit
) {
    val valid = minuteText.toIntOrNull()?.let { it in 5..180 } == true
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 18.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 22.dp
            ),
        horizontalAlignment = Alignment.Start
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(Accent, Blue))),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.material3.Icon(Icons.Filled.Shield, null, tint = Night, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column {
                Text("YouWill", color = White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp)
                Text("CHOOSE YOURSELF", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            }
            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (strongMode) Color(0x223ED6A1) else Color(0x22F5B95D))
                    .padding(horizontal = 10.dp, vertical = 7.dp)
            ) {
                Text(
                    if (strongMode) "STRONG MODE" else "BASIC MODE",
                    color = if (strongMode) Accent else Color(0xFFFFC979),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
            }
        }

        Spacer(Modifier.height(34.dp))
        Text("MAKE A PROMISE\nTO YOURSELF.", color = White, fontSize = 35.sp, lineHeight = 39.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.1).sp)
        Spacer(Modifier.height(10.dp))
        Text("Step away from distractions. Give the urge time to fade.", color = Muted, fontSize = 14.sp, lineHeight = 21.sp)

        Spacer(Modifier.height(26.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(18.dp, RoundedCornerShape(26.dp))
                .clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF1C2D49), Panel)))
                .border(1.dp, Color(0x334E6D96), RoundedCornerShape(26.dp))
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("YOUR FOCUS WINDOW", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
                Spacer(Modifier.weight(1f))
                Text("5 MIN – 3 HRS", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = minuteText,
                    onValueChange = onTextChange,
                    modifier = Modifier.width(132.dp),
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    placeholder = { Text("25", color = Muted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Accent,
                        unfocusedBorderColor = Color(0x445C7090),
                        cursorColor = Accent,
                        focusedContainerColor = Color(0x33101A2B),
                        unfocusedContainerColor = Color(0x33101A2B)
                    ),
                    shape = RoundedCornerShape(17.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("MINUTES", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text("You choose the time", color = Muted, fontSize = 11.sp)
                }
            }
            if (!valid) {
                Spacer(Modifier.height(7.dp))
                Text("Enter a whole number from 5 to 180.", color = Color(0xFFFF9D9D), fontSize = 11.sp)
            }
            Spacer(Modifier.height(16.dp))
            Slider(
                value = minutes.toFloat(),
                onValueChange = { onMinutesChange((it / 5f).roundToInt() * 5) },
                valueRange = 5f..180f,
                steps = 34,
                colors = SliderDefaults.colors(
                    thumbColor = Accent,
                    activeTrackColor = Accent,
                    inactiveTrackColor = Color(0xFF34445E)
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("5 min", color = Muted, fontSize = 10.sp)
                Text("90 min", color = Muted, fontSize = 10.sp)
                Text("180 min", color = Muted, fontSize = 10.sp)
            }
            Spacer(Modifier.height(18.dp))
            Text("QUICK PICKS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                PresetChip("5m", 5, minutes == 5, onMinutesChange, Modifier.weight(1f))
                PresetChip("15m", 15, minutes == 15, onMinutesChange, Modifier.weight(1f))
                PresetChip("30m", 30, minutes == 30, onMinutesChange, Modifier.weight(1f))
                PresetChip("1h", 60, minutes == 60, onMinutesChange, Modifier.weight(1f))
                PresetChip("3h", 180, minutes == 180, onMinutesChange, Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(22.dp))
        Button(
            onClick = onStart,
            enabled = valid,
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .shadow(if (valid) 12.dp else 0.dp, RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Accent,
                contentColor = Night,
                disabledContainerColor = Color(0xFF354254),
                disabledContentColor = Muted
            )
        ) {
            androidx.compose.material3.Icon(Icons.Filled.Lock, null, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(10.dp))
            Text("START MY LOCK", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.3.sp)
        }

        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(horizontal = 4.dp)) {
            androidx.compose.material3.Icon(Icons.Filled.Shield, null, tint = if (strongMode) Accent else Color(0xFFFFC979), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                if (strongMode) "Managed-device lock is available. Emergency calling remains accessible."
                else "Basic mode uses Android screen pinning. For a stronger lock, this phone must be set up as a managed device.",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
        }
        Spacer(Modifier.height(13.dp))
        Text("No pause button. No early-unlock button. Just your decision.", color = Color(0xFF71819C), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun PresetChip(label: String, value: Int, selected: Boolean, onClick: (Int) -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(38.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) Color(0x3378E7C0) else Color(0x1FFFFFFF))
            .border(1.dp, if (selected) Accent.copy(alpha = 0.75f) else Color(0x224F6280), RoundedCornerShape(12.dp))
            .clickable { onClick(value) },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) Accent else White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ActiveScreen(remainingMillis: Long, totalMillis: Long, onEmergency: () -> Unit) {
    val progressTarget = (remainingMillis.toFloat() / totalMillis.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
    val progress by animateFloatAsState(progressTarget, animationSpec = tween(700, easing = FastOutSlowInEasing), label = "timerProgress")
    val totalSeconds = (remainingMillis / 1000L).coerceAtLeast(0L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    val clock = if (hours > 0) String.format("%d:%02d:%02d", hours, minutes, seconds) else String.format("%02d:%02d", minutes, seconds)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 24.dp, bottom = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Icon(Icons.Filled.Shield, null, tint = Accent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("YOUWILL SESSION", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, letterSpacing = 2.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text("YOU'RE IN CONTROL.", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }

        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(270.dp)) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val stroke = 13.dp.toPx()
                val inset = stroke / 2f
                drawArc(
                    color = Color(0xFF283650),
                    startAngle = -90f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = androidx.compose.ui.geometry.Offset(inset, inset),
                    size = Size(size.width - stroke, size.height - stroke),
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                drawArc(
                    brush = Brush.sweepGradient(listOf(Accent, Blue, Accent)),
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    topLeft = androidx.compose.ui.geometry.Offset(inset, inset),
                    size = Size(size.width - stroke, size.height - stroke),
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("TIME LEFT", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                Text(clock, color = White, fontSize = 43.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.5).sp)
                Text("STAY WITH IT", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text("Let the moment pass.", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text("You don't have to act on every urge.\nOne minute at a time.", color = Muted, fontSize = 14.sp, lineHeight = 21.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(26.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Panel)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0x2278E7C0)), contentAlignment = Alignment.Center) {
                    androidx.compose.material3.Icon(Icons.Filled.Lock, null, tint = Accent, modifier = Modifier.size(17.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("FOCUS MODE IS ON", color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("This session ends when the timer reaches zero.", color = Muted, fontSize = 10.sp)
                }
                Box(Modifier.size(7.dp).clip(CircleShape).background(Accent))
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onEmergency,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF202B40), contentColor = White)
            ) {
                androidx.compose.material3.Icon(Icons.Filled.Call, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("EMERGENCY CALL", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
private fun DoneScreen(onContinue: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(86.dp).clip(CircleShape).background(Color(0x2278E7C0)), contentAlignment = Alignment.Center) {
            androidx.compose.material3.Icon(Icons.Filled.CheckCircle, null, tint = Accent, modifier = Modifier.size(48.dp))
        }
        Spacer(Modifier.height(25.dp))
        Text("YOU DID IT.", color = White, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp)
        Spacer(Modifier.height(10.dp))
        Text("You kept the promise you made to yourself. Take a breath and choose what comes next.", color = Muted, fontSize = 14.sp, lineHeight = 22.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(30.dp))
        Button(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(17.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Night)
        ) {
            Text("CONTINUE", fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
        }
    }
}

private fun beginFocusLock(context: Context, activity: Activity) {
    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    if (dpm.isDeviceOwnerApp(context.packageName)) {
        val admin = ComponentName(context, YouWillAdminReceiver::class.java)
        try {
            val dialIntent = Intent(Intent.ACTION_DIAL)
            val dialPackage = context.packageManager.resolveActivity(dialIntent, 0)?.activityInfo?.packageName
            val allowlist = listOfNotNull(context.packageName, dialPackage).distinct().toTypedArray()
            dpm.setLockTaskPackages(admin, allowlist)
            // Keep Android's keyguard and global actions available for emergencies.
            // Home, Overview and notification shade remain unavailable in lock-task mode.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                dpm.setLockTaskFeatures(
                    admin,
                    DevicePolicyManager.LOCK_TASK_FEATURE_GLOBAL_ACTIONS or
                        DevicePolicyManager.LOCK_TASK_FEATURE_KEYGUARD or
                        DevicePolicyManager.LOCK_TASK_FEATURE_SYSTEM_INFO
                )
            }
            activity.startLockTask()
        } catch (_: SecurityException) {
            // Fall back to Android's user-confirmed screen-pinning mode.
            activity.startLockTask()
        } catch (_: IllegalStateException) {
            activity.startLockTask()
        }
    } else {
        // On an unmanaged phone Android shows its own screen-pinning confirmation.
        // This is intentionally labelled BASIC MODE in the UI because it is easier to exit.
        try { activity.startLockTask() } catch (_: IllegalStateException) { }
    }
}

private fun endFocusLock(activity: Activity) {
    try { activity.stopLockTask() } catch (_: IllegalStateException) { }
    val dpm = activity.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    if (dpm.isDeviceOwnerApp(activity.packageName)) {
        try {
            dpm.setLockTaskPackages(ComponentName(activity, YouWillAdminReceiver::class.java), emptyArray())
        } catch (_: SecurityException) { }
    }
}

private fun openEmergencyDialer(context: Context) {
    try {
        context.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        // Android's built-in lock-screen emergency calling remains the fallback.
    }
}
